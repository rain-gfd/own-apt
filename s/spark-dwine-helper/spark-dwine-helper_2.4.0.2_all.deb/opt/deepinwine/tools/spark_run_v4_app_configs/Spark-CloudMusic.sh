#!/bin/bash
CallProcess "$@"
sleep 2
/opt/apps/com.163.music.spark/files/disable_cloudmusic_shadows
