#!/bin/bash
XDG_CURRENT_DESKTOP=Deepin
/opt/apps/com.github.ccc-app-manager/files/ccc-app-manager -platformtheme deepin "$@"
